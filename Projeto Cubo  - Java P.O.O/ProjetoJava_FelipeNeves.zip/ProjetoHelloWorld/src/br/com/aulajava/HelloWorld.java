package br.com.aulajava;

public class HelloWorld {

	private static String mensagem ;
	
	/**
	 * Metodo principal
	 * @param args
	 */
		public static void main (String[]args) {
			// atribuindo valor para variavel 
			mensagem = "Ol� mundo!!";
			
			// exibindo o valor atribuido
			
			System.out.println(mensagem);
		}
		

	

}
